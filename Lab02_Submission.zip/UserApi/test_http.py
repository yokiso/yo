import base64
from contextlib import closing
from datetime import datetime, timezone
import hashlib
from http.client import HTTPConnection
import json
import os
from pathlib import Path
import queue
import secrets
import sqlite3
import subprocess
import sys
import tempfile
from threading import Thread
import time


ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT.parent / "evidence" / "api.txt"
ITERATIONS = 600_000


def make_hash():
    password = secrets.token_bytes(24)
    salt = secrets.token_bytes(16)
    key = hashlib.pbkdf2_hmac("sha256", password, salt, ITERATIONS, 32)
    salt64 = base64.b64encode(salt).decode("ascii")
    key64 = base64.b64encode(key).decode("ascii")
    return f"pbkdf2-sha256${ITERATIONS}${salt64}${key64}"


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def get_port(server, startup_output):
    lines = queue.Queue()

    def read_output():
        for line in server.stdout:
            lines.put(line.rstrip())
        lines.put(None)

    Thread(target=read_output, daemon=True).start()
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline:
        try:
            line = lines.get(timeout=max(0, deadline - time.monotonic()))
        except queue.Empty:
            break
        if line is None:
            break
        startup_output.append(line)
        marker = "Now listening on: http://127.0.0.1:"
        if marker in line:
            return int(line.split(marker, maxsplit=1)[1])
    raise RuntimeError("API не сообщил адрес loopback при запуске.\n" + "\n".join(startup_output))


def http_cases(port, db_path, report):
    checks = 0
    first_hash = make_hash()
    updated_hash = make_hash()
    second_hash = make_hash()

    def request(label, method, path, status, payload=None, *, media="application/json"):
        nonlocal checks
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8") if isinstance(payload, dict) else payload
        headers = {"Accept": "application/json, application/problem+json"}
        if body is not None:
            headers["Content-Type"] = media
        with closing(HTTPConnection("127.0.0.1", port, timeout=5)) as connection:
            connection.request(method, path, body, headers)
            response = connection.getresponse()
            actual = response.status
            response_body = response.read().decode("utf-8")
            location = response.getheader("Location")
            content_type = response.getheader("Content-Type")
        report.append(f"{label}\n> {method} {path}\n< {actual} {response.reason}")
        if location is not None:
            report.append(f"< Location: {location}")
        if content_type is not None:
            report.append(f"< Content-Type: {content_type}")
        report.append(f"< {response_body}" if response_body else "< [пустое тело]")
        report.append("")
        require(actual == status, f"{label}: ожидался HTTP {status}, получен {actual}")
        expected_media = "application/problem+json" if status >= 400 else "application/json"
        require(content_type and content_type.split(";", 1)[0] == expected_media,
                f"{label}: неверный Content-Type")
        data = json.loads(response_body)
        if status >= 400:
            require(data.get("status") == status, f"{label}: неверный ProblemDetails.status")
        elif method == "DELETE":
            require(data == {"deleted": True}, f"{label}: ожидалось подтверждение удаления")
        else:
            require(set(data) == {"id", "login"}, f"{label}: неверный набор полей ответа")
        require("passhash" not in response_body.lower() if status < 400 else True,
                f"{label}: в ответе есть поле passHash")
        require(all(value not in response_body for value in (first_hash, updated_hash, second_hash)),
                f"{label}: в ответе есть значение хеша")
        checks += 1
        return data, location

    def payload(login, value=first_hash):
        return {"login": login, "passHash": value}

    login = "Анна"
    updated_login = "О’Нил O'Neil"
    created, location = request("Создание пользователя", "POST", "/user", 201, payload(login))
    user_id = created["id"]
    path = f"/user/{user_id}"
    require(type(user_id) is int and user_id > 0, "POST: ожидался положительный целый Id")
    require(location == path and created["login"] == login, "POST: неверные Location или Login")
    require(request("Чтение пользователя", "GET", path, 200)[0] == created, "GET: данные отличаются")
    request("Дубликат при создании", "POST", "/user", 409, payload(login, second_hash))
    second, _ = request("Создание второго пользователя", "POST", "/user", 201, payload("Второй", second_hash))
    second_path = f"/user/{second['id']}"
    require(second["id"] != user_id and second["login"] == "Второй", "POST: неверные данные второго пользователя")
    request("Дубликат при обновлении", "PUT", path, 409, payload(second["login"], updated_hash))
    require(request("Чтение после отклонённого обновления", "GET", path, 200)[0] == created,
            "Отклонённое обновление изменило запись")

    expected = {"id": user_id, "login": updated_login}
    require(request("Обновление логина и хеша", "PUT", path, 200, payload(updated_login, updated_hash))[0] == expected,
            "PUT: неверные данные после обновления")
    require(request("Чтение обновлённой записи", "GET", path, 200)[0] == expected, "GET: обновление не сохранилось")

    request("Пробелы вокруг логина", "POST", "/user", 400, payload(" Анна "))
    request("Слишком длинный логин", "POST", "/user", 400, payload("a" * 65))
    request("Хеш отсутствует", "POST", "/user", 400, {"login": "test"})
    request("Открытый пароль вместо хеша", "POST", "/user", 400, payload("test", "example-password"))
    request("Неверное число итераций", "POST", "/user", 400,
            payload("test", first_hash.replace("$600000$", "$600001$", 1)))
    scheme, rounds, salt, key = first_hash.split("$")
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    noncanonical_salt = salt[:-3] + alphabet[alphabet.index(salt[-3]) + 1] + "=="
    request("Неканоническая запись соли Base64", "POST", "/user", 400,
            payload("test", f"{scheme}${rounds}${noncanonical_salt}${key}"))
    request("Неверный размер ключа", "POST", "/user", 400,
            payload("test", f"{scheme}${rounds}${salt}${key[:-2]}=="))
    request("Неверный хеш при обновлении", "PUT", path, 400, payload("Другое имя", "bad-hash"))
    request("Некорректный JSON", "POST", "/user", 400, b'{"login":')
    request("Лишнее поле id", "POST", "/user", 400, {**payload("test"), "id": 100})
    request("Неподдерживаемый Content-Type", "POST", "/user", 415, b"test", media="text/plain")
    request("Нецелочисленный Id", "GET", "/user/foo", 400)
    request("Неположительный Id", "GET", "/user/0", 400)

    with closing(sqlite3.connect(db_path)) as db:
        tables = db.execute("SELECT name FROM sqlite_schema WHERE type = 'table' ORDER BY name").fetchall()
        require(tables == [("User",)], "SQLite: ожидалась единственная таблица User")
        columns = [(r[1], r[2], r[5]) for r in db.execute('PRAGMA table_info("User")')]
        require(columns == [("Id", "INTEGER", 1), ("Login", "TEXT", 0), ("PassHash", "TEXT", 0)],
                "SQLite: неверные столбцы или первичный ключ")
        unique_columns = [
            [row[2] for row in db.execute("SELECT * FROM pragma_index_info(?)", (index[1],))]
            for index in db.execute('PRAGMA index_list("User")') if index[2]
        ]
        require(unique_columns == [["Login"]], "SQLite: ожидался UNIQUE для Login")
        stored = db.execute('SELECT Login, PassHash FROM "User" WHERE Id = ?', (user_id,)).fetchone()
        require(stored == (updated_login, updated_hash), "SQLite: обновлённый логин или хеш не сохранился")
    report.append("SQLite OK: единственная таблица User(Id INTEGER PK, Login TEXT UNIQUE, PassHash TEXT).")
    report.append("SQLite OK: новые логин и хеш сохранены.")
    report.append("")

    request("Удаление пользователя", "DELETE", path, 200)
    request("Чтение после удаления", "GET", path, 404)
    request("Обновление отсутствующего пользователя", "PUT", path, 404, payload("Другой логин"))
    request("Повторное удаление", "DELETE", path, 404)
    request("Удаление второго пользователя", "DELETE", second_path, 200)
    with closing(sqlite3.connect(db_path)) as db:
        require(db.execute('SELECT COUNT(*) FROM "User"').fetchone() == (0,), "SQLite: остались записи")
    report.append("SQLite OK: после удаления таблица пуста.")
    report.append(f"Итог: {checks} HTTP-проверок пройдены. Схема и сохранение данных проверены в SQLite.")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    dotnet = Path(os.environ["LOCALAPPDATA"]) / "Lab02Dotnet" / "dotnet.exe"
    report = ["ЛР2, часть 3 — фактический прогон UserApi", datetime.now(timezone.utc).isoformat(timespec="seconds")]
    try:
        sdk = subprocess.check_output([dotnet, "--version"], cwd=ROOT, text=True).strip()
        report.append(f".NET SDK {sdk}")
        build = subprocess.run([dotnet, "build", "UserApi.csproj", "--nologo"], cwd=ROOT,
                               capture_output=True, encoding="utf-8", errors="replace")
        require(build.returncode == 0, f"Сборка завершилась с ошибкой:\n{build.stdout}\n{build.stderr}")
        with tempfile.TemporaryDirectory(prefix=".http-test-", dir=ROOT) as temp:
            db_path = Path(temp) / "test.db"
            env = {**os.environ, "Logging__LogLevel__Default": "Warning", "Logging__LogLevel__Microsoft.Hosting.Lifetime": "Information"}
            with subprocess.Popen(
                [dotnet, ROOT / "bin" / "Debug" / "net10.0" / "UserApi.dll",
                 "--UserApi:Port=0", f"--UserApi:DbPath={db_path}"], cwd=ROOT, env=env,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, encoding="utf-8", errors="replace",
            ) as server:
                try:
                    port = get_port(server, [])
                    report.extend([f"http://127.0.0.1:{port} (временная SQLite БД)", ""])
                    http_cases(port, db_path, report)
                finally:
                    server.terminate()
                    server.wait(timeout=5)
    except Exception as exc:
        report.append(f"ОШИБКА: {type(exc).__name__}: {exc}")
        raise
    finally:
        EVIDENCE.parent.mkdir(parents=True, exist_ok=True)
        output = "\n".join(report) + "\n"
        EVIDENCE.write_text(output, encoding="utf-8")
        print(output, end="")


if __name__ == "__main__":
    main()
