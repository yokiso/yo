using System.Net;
using System.Text.Json.Serialization;
using Microsoft.Data.Sqlite;

var builder = WebApplication.CreateBuilder(args);
var port = builder.Configuration.GetValue("UserApi:Port", 5073);
var dbPath = builder.Configuration["UserApi:DbPath"] ?? "users.db";
var connectionString = new SqliteConnectionStringBuilder
{
    DataSource = Path.GetFullPath(dbPath, builder.Environment.ContentRootPath),
    Mode = SqliteOpenMode.ReadWriteCreate
}.ToString();

builder.Configuration["AllowedHosts"] = "127.0.0.1";
builder.WebHost.ConfigureKestrel(options =>
{
    options.Listen(IPAddress.Loopback, port);
    options.Limits.MaxRequestBodySize = 4096;
});
builder.Services.Configure<RouteHandlerOptions>(options => options.ThrowOnBadRequest = false);
builder.Services.AddProblemDetails();

var app = builder.Build();
app.UseExceptionHandler();
app.UseStatusCodePages();

using (var connection = OpenDatabase())
using (var command = connection.CreateCommand())
{
    command.CommandText = """
        CREATE TABLE IF NOT EXISTS "User" (
            Id INTEGER PRIMARY KEY,
            Login TEXT NOT NULL UNIQUE,
            PassHash TEXT NOT NULL
        );
        """;
    command.ExecuteNonQuery();
}

app.MapPost("/user", (UserInput input) =>
{
    if (Validate(input) is { } error)
        return error;

    using var connection = OpenDatabase();
    using var command = connection.CreateCommand();
    command.CommandText = """
        INSERT INTO "User" (Login, PassHash) VALUES ($login, $hash) RETURNING Id;
        """;
    AddUserParameters(command, input);

    try
    {
        var id = (long)command.ExecuteScalar()!;
        return Results.Created($"/user/{id}", new UserView(id, input.Login!));
    }
    catch (SqliteException exception) when (IsDuplicateLogin(exception))
    {
        return DuplicateLogin();
    }
});

app.MapGet("/user/{id}", (long id) =>
{
    if (id <= 0)
        return InvalidId();

    using var connection = OpenDatabase();
    using var command = connection.CreateCommand();
    command.CommandText = """SELECT Id, Login FROM "User" WHERE Id = $id;""";
    command.Parameters.AddWithValue("$id", id);
    using var reader = command.ExecuteReader();
    return reader.Read()
        ? Results.Ok(new UserView(reader.GetInt64(0), reader.GetString(1)))
        : MissingUser();
});

app.MapPut("/user/{id}", (long id, UserInput input) =>
{
    if (id <= 0)
        return InvalidId();
    if (Validate(input) is { } error)
        return error;

    using var connection = OpenDatabase();
    using var command = connection.CreateCommand();
    command.CommandText = """
        UPDATE "User" SET Login = $login, PassHash = $hash WHERE Id = $id;
        """;
    command.Parameters.AddWithValue("$id", id);
    AddUserParameters(command, input);

    try
    {
        return command.ExecuteNonQuery() == 0
            ? MissingUser()
            : Results.Ok(new UserView(id, input.Login!));
    }
    catch (SqliteException exception) when (IsDuplicateLogin(exception))
    {
        return DuplicateLogin();
    }
});

app.MapDelete("/user/{id}", (long id) =>
{
    if (id <= 0)
        return InvalidId();

    using var connection = OpenDatabase();
    using var command = connection.CreateCommand();
    command.CommandText = """DELETE FROM "User" WHERE Id = $id;""";
    command.Parameters.AddWithValue("$id", id);
    return command.ExecuteNonQuery() == 0 ? MissingUser() : Results.Ok(new { deleted = true });
});

app.Run();

SqliteConnection OpenDatabase()
{
    var connection = new SqliteConnection(connectionString);
    try
    {
        connection.Open();
        return connection;
    }
    catch
    {
        connection.Dispose();
        throw;
    }
}

static void AddUserParameters(SqliteCommand command, UserInput input)
{
    command.Parameters.AddWithValue("$login", input.Login!);
    command.Parameters.AddWithValue("$hash", input.PassHash!);
}

static IResult? Validate(UserInput input)
{
    var login = input.Login;
    if (string.IsNullOrEmpty(login) || login.Length > 64 || login != login.Trim()
        || login.Any(char.IsControl))
    {
        return Results.Problem(statusCode: 400, title:
            "Login must contain 1 to 64 UTF-16 code units, with no control characters or surrounding whitespace.");
    }

    if (!IsEncodedHash(input.PassHash))
        return Results.Problem(statusCode: 400, title: "Invalid PBKDF2-SHA256 passHash format.");

    return null;
}

static bool IsEncodedHash(string? hash)
{
    const string prefix = "pbkdf2-sha256$600000$";
    const int saltLength = 24;
    const int keyLength = 44;
    if (hash is null || hash.Length != prefix.Length + saltLength + 1 + keyLength
        || !hash.StartsWith(prefix, StringComparison.Ordinal)
        || hash[prefix.Length + saltLength] != '$')
    {
        return false;
    }

    ReadOnlySpan<char> salt = hash.AsSpan(prefix.Length, saltLength);
    ReadOnlySpan<char> key = hash.AsSpan(prefix.Length + saltLength + 1, keyLength);
    return IsCanonicalBase64(salt, stackalloc byte[16])
        && IsCanonicalBase64(key, stackalloc byte[32]);
}

static bool IsCanonicalBase64(ReadOnlySpan<char> value, Span<byte> decoded)
{
    Span<char> reencoded = stackalloc char[value.Length];
    return Convert.TryFromBase64Chars(value, decoded, out var bytesWritten)
        && bytesWritten == decoded.Length
        && Convert.TryToBase64Chars(decoded, reencoded, out var charsWritten)
        && charsWritten == value.Length
        && value.SequenceEqual(reencoded);
}

static bool IsDuplicateLogin(SqliteException exception) =>
    exception.SqliteExtendedErrorCode == 2067; // SQLITE_CONSTRAINT_UNIQUE

static IResult DuplicateLogin() => Results.Problem(statusCode: 409, title: "Login already exists.");
static IResult MissingUser() => Results.Problem(statusCode: 404, title: "User not found.");
static IResult InvalidId() => Results.Problem(statusCode: 400, title: "Id must be a positive integer.");

[JsonUnmappedMemberHandling(JsonUnmappedMemberHandling.Disallow)]
internal sealed record UserInput(string? Login, string? PassHash);
internal sealed record UserView(long Id, string Login);
