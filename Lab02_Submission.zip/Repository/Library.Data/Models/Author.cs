namespace Library.Data.Models;

public sealed class Author
{
    public int Id { get; set; }
    public required string Name { get; set; }
    public ICollection<Book> Books { get; } = new List<Book>();
}
