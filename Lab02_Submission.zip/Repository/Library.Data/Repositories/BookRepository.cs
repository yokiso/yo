using Library.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace Library.Data.Repositories;

public interface IBookRepository : IRepository<Book>, IAsyncRepository<Book>
{
    IReadOnlyList<Book> FindByTitle(string titlePart);
    Task<IReadOnlyList<Book>> GetByAuthorAsync(int authorId, CancellationToken cancellationToken = default);
}

public sealed class BookRepository(LibraryContext context) : GenericRepository<Book>(context), IBookRepository
{
    public IReadOnlyList<Book> FindByTitle(string titlePart) => Entities
        .Where(book => book.Title.Contains(titlePart))
        .OrderBy(book => book.Id)
        .ToList();

    public async Task<IReadOnlyList<Book>> GetByAuthorAsync(int authorId, CancellationToken cancellationToken = default) =>
        await Entities.Include(book => book.Author)
            .Where(book => book.AuthorId == authorId)
            .OrderBy(book => book.Id)
            .ToListAsync(cancellationToken);
}
