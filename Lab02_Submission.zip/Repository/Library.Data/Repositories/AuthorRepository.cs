using Library.Data.Models;

namespace Library.Data.Repositories;

public interface IAuthorRepository : IRepository<Author>, IAsyncRepository<Author>
{
    IReadOnlyList<Author> FindByName(string namePart);
}

public sealed class AuthorRepository(LibraryContext context) : GenericRepository<Author>(context), IAuthorRepository
{
    public IReadOnlyList<Author> FindByName(string namePart) => Entities
        .Where(author => author.Name.Contains(namePart))
        .OrderBy(author => author.Id)
        .ToList();
}
