using Microsoft.EntityFrameworkCore;

namespace Library.Data.Repositories;

public class GenericRepository<T>(LibraryContext context) : IRepository<T>, IAsyncRepository<T> where T : class
{
    protected DbSet<T> Entities { get; } = context.Set<T>();

    public T? GetById(int id) => Entities.Find(id);

    public IReadOnlyList<T> GetAll() => Entities.ToList();

    public void Add(T entity) => Entities.Add(entity);

    public void Update(T entity) => Entities.Update(entity);

    public bool Delete(int id)
    {
        var entity = GetById(id);
        if (entity is null)
            return false;

        Entities.Remove(entity);
        return true;
    }

    public Task<T?> GetByIdAsync(int id, CancellationToken cancellationToken = default) =>
        Entities.FindAsync([id], cancellationToken).AsTask();

    public async Task<IReadOnlyList<T>> GetAllAsync(CancellationToken cancellationToken = default) =>
        await Entities.ToListAsync(cancellationToken);

    public async Task AddAsync(T entity, CancellationToken cancellationToken = default) =>
        await Entities.AddAsync(entity, cancellationToken);

    public async Task<bool> UpdateAsync(int id, Action<T> applyChanges, CancellationToken cancellationToken = default)
    {
        var entity = await GetByIdAsync(id, cancellationToken);
        if (entity is null)
            return false;

        applyChanges(entity);
        return true;
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await GetByIdAsync(id, cancellationToken);
        if (entity is null)
            return false;

        Entities.Remove(entity);
        return true;
    }
}
