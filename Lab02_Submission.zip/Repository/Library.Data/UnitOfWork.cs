using Library.Data.Repositories;
using Microsoft.EntityFrameworkCore;

namespace Library.Data;

public sealed class UnitOfWork(DbContextOptions<LibraryContext> options) : IDisposable, IAsyncDisposable
{
    private readonly LibraryContext _context = new(options);

    private IAuthorRepository? _authors;
    private IBookRepository? _books;

    public IAuthorRepository Authors => _authors ??= new AuthorRepository(_context);
    public IBookRepository Books => _books ??= new BookRepository(_context);

    public int SaveChanges() => _context.SaveChanges();

    public Task<int> SaveChangesAsync(CancellationToken cancellationToken = default) =>
        _context.SaveChangesAsync(cancellationToken);

    public void Dispose() => _context.Dispose();

    public ValueTask DisposeAsync() => _context.DisposeAsync();
}
