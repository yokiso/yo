using System.Text;
using Library.Data;
using Library.Data.Models;
using Library.Data.Repositories;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

Console.OutputEncoding = Encoding.UTF8;
var directory = Directory.CreateTempSubdirectory("lab02-library-");
try
{
    var connectionString = new SqliteConnectionStringBuilder
    {
        DataSource = Path.Combine(directory.FullName, "library.db"),
        ForeignKeys = true,
        Pooling = false
    }.ToString();
    var options = new DbContextOptionsBuilder<LibraryContext>().UseSqlite(connectionString).Options;

    await using (var context = new LibraryContext(options))
        await context.Database.EnsureCreatedAsync();

    Console.WriteLine("Часть 2. Репозитории библиотеки (EF Core SQLite)");

    var bulgakov = new Author { Name = "Михаил Булгаков" };
    var gogol = new Author { Name = "Николай Гоголь" };
    var master = new Book { Title = "Мастер и Маргарита", PublicationYear = 1966, Author = bulgakov };
    var souls = new Book { Title = "Мёртвые души", PublicationYear = 1842, Author = gogol };

    await using (var work = new UnitOfWork(options))
    {
        IRepository<Book> syncBooks = work.Books;
        IAsyncRepository<Book> asyncBooks = work.Books;
        work.Authors.Add(bulgakov);
        await work.Authors.AddAsync(gogol);
        syncBooks.Add(master);
        await asyncBooks.AddAsync(souls);

        await using (var beforeSave = new UnitOfWork(options))
        {
            Check(beforeSave.Authors.GetAll().Count == 0 && beforeSave.Books.GetAll().Count == 0,
                "До SaveChanges обе таблицы пусты в другом контексте");
        }

        Check(work.SaveChanges() == 4, "Один SaveChanges сохранил двух авторов и две книги");
    }

    await using (var work = new UnitOfWork(options))
    {
        IRepository<Book> syncBooks = work.Books;
        IAsyncRepository<Book> asyncBooks = work.Books;
        var savedMaster = syncBooks.GetById(master.Id);
        var savedSouls = await asyncBooks.GetByIdAsync(souls.Id);
        Check(savedMaster is { Title: "Мастер и Маргарита", PublicationYear: 1966 } &&
              savedMaster.AuthorId == bulgakov.Id && syncBooks.GetAll().Count == 2,
            "Create / Read (sync) — найдены сохранённая книга и список книг");
        Check(savedSouls is { Title: "Мёртвые души", PublicationYear: 1842 } &&
              savedSouls.AuthorId == gogol.Id && (await asyncBooks.GetAllAsync()).Count == 2,
            "Create / Read (async) — найдены сохранённая книга и список книг");
        Check(work.Authors.FindByName("Булгаков").Single().Id == bulgakov.Id &&
              work.Authors.FindByName("Толстой").Count == 0,
            "Поиск автора по части имени вернул Булгакова, для Толстого результат пуст");
        Check(work.Books.FindByTitle("Маргарита").Single().Id == master.Id &&
              work.Books.FindByTitle("Ревизор").Count == 0,
            "Поиск по названию вернул «Мастер и Маргарита», для «Ревизора» результат пуст");
        var booksByGogol = await work.Books.GetByAuthorAsync(gogol.Id);
        Check(booksByGogol is [{ Author.Name: "Николай Гоголь" } book] && book.Id == souls.Id,
            "Поиск книг по автору вернул «Мёртвые души» вместе с данными Гоголя");

        savedMaster!.Title = "Мастер и Маргарита (издание 1967 года)";
        savedMaster.PublicationYear = 1967;
        syncBooks.Update(savedMaster);
        Check(await asyncBooks.UpdateAsync(souls.Id, book => book.Title = "Мёртвые души. Том 1"),
            "UpdateAsync нашёл книгу и изменил её название");
        Check(await work.SaveChangesAsync() == 2, "SaveChangesAsync сохранил обе правки");
    }

    await using (var work = new UnitOfWork(options))
    {
        IRepository<Book> syncBooks = work.Books;
        IAsyncRepository<Book> asyncBooks = work.Books;
        Check(syncBooks.GetById(master.Id) is { Title: "Мастер и Маргарита (издание 1967 года)", PublicationYear: 1967 },
            "Update (sync) — новое название и год прочитаны из SQLite");
        Check(await asyncBooks.GetByIdAsync(souls.Id) is { Title: "Мёртвые души. Том 1" },
            "Update (async) — новое название прочитано из SQLite");
        Check(syncBooks.Delete(master.Id), "Delete нашёл и пометил книгу на удаление");
        Check(await asyncBooks.DeleteAsync(souls.Id), "DeleteAsync нашёл и пометил книгу на удаление");
        Check(await work.SaveChangesAsync() == 2, "SaveChangesAsync удалил обе книги");
    }

    await using (var work = new UnitOfWork(options))
    {
        Check(work.Books.GetById(master.Id) is null && await work.Books.GetByIdAsync(souls.Id) is null &&
              (await work.Books.GetAllAsync()).Count == 0,
            "Delete (sync / async) — книги отсутствуют в SQLite");
        Check(work.Authors.GetAll().Count == 2, "После удаления книг оба автора остались в SQLite");
    }

    Console.WriteLine("Все проверки пройдены.");
}
finally
{
    directory.Delete(recursive: true);
}

static void Check(bool condition, string description)
{
    if (!condition)
        throw new InvalidOperationException($"Проверка не пройдена: {description}");

    Console.WriteLine($"[OK] {description}");
}
