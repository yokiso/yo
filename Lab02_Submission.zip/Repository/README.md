# ЛР2. Часть 2. Репозитории библиотеки

`Library.Data` — библиотека классов на .NET 10 с EF Core и SQLite. `Library.Demo` — отдельное консольное приложение, которое проверяет репозитории на файловой базе SQLite.

## ER-диаграмма

```mermaid
erDiagram
    AUTHORS ||--o{ BOOKS : writes
    AUTHORS {
        int Id PK
        string Name
    }
    BOOKS {
        int Id PK
        string Title
        int PublicationYear
        int AuthorId FK
    }
```

У книги ровно один автор. У автора может быть от нуля до нескольких книг. `Books.AuthorId` ссылается на `Authors.Id`. Удаление автора с книгами ограничено внешним ключом.

## Репозитории

- `IRepository<T>` задаёт синхронные операции `GetById`, `GetAll`, `Add`, `Update` и `Delete` для сущностей с целочисленным ключом.
- `GenericRepository<T>` реализует `IRepository<T>` и асинхронный контракт `IAsyncRepository<T>`. `UpdateAsync` загружает сущность по ключу и применяет переданные изменения. `UpdateAsync` и оба метода удаления возвращают `false`, если запись не найдена.
- `IAuthorRepository` добавляет поиск авторов по части имени. `IBookRepository` добавляет поиск книг по части названия и асинхронную выборку по идентификатору автора. `AuthorRepository` и `BookRepository` наследуют общий CRUD от `GenericRepository<T>`.
- `UnitOfWork` предоставляет оба репозитория с одним `LibraryContext`. Вызов `SaveChanges` или `SaveChangesAsync` сохраняет накопленные изменения обоих репозиториев.

## Запуск

Выполните из `lab02/Repository` в PowerShell. Если SDK доступен через `PATH`, можно вызывать `dotnet` напрямую.

```powershell
$dotnet = Join-Path $env:LOCALAPPDATA 'Lab02Dotnet\dotnet.exe'
& $dotnet build .\Repository.slnx
& $dotnet run --project .\Library.Demo --no-build
```

Демо создаёт отдельную временную базу при каждом запуске и удаляет её по завершении. Оно проверяет общее сохранение изменений двух репозиториев, поиск и обе версии CRUD для книг. Каждая проверка сохранённых изменений читает данные через новый контекст. При провале любой проверки программа завершится с ошибкой.

Фактический вывод запуска сохранён в [repository.txt](../evidence/repository.txt).
