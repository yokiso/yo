using System.Globalization;
using System.Text;

namespace Lab02.Interfaces
{
    public interface IMovable
    {
        void Move(int x, int y);
    }

    public sealed class Point(int x, int y) : IMovable
    {
        public int X { get; private set; } = x;
        public int Y { get; private set; } = y;

        public void Move(int x, int y)
        {
            X += x;
            Y += y;
        }

        public override string ToString() => $"({X}, {Y})";
    }

    public interface IDrawable
    {
        void Draw();
    }

    public interface IShape
    {
        double GetArea();
        double GetPerimeter();
    }

    public interface I3DShape : IShape
    {
        double GetVolume();
    }

    public sealed class Circle(double radius) : IDrawable, IShape
    {
        public void Draw() => Console.WriteLine($"  Circle.Draw: радиус {radius}");
        public double GetArea() => Math.PI * radius * radius;
        public double GetPerimeter() => 2 * Math.PI * radius;
    }

    public sealed class Rectangle(double width, double height) : IDrawable, IShape
    {
        public void Draw() => Console.WriteLine($"  Rectangle.Draw: стороны {width} × {height}");
        public double GetArea() => width * height;
        public double GetPerimeter() => 2 * (width + height);
    }

    public sealed class Cube(double side) : I3DShape
    {
        public double GetArea() => 6 * side * side;

        // Для куба периметр — суммарная длина двенадцати рёбер.
        public double GetPerimeter() => 12 * side;
        public double GetVolume() => side * side * side;
    }

    public interface IPayable
    {
        void Pay(decimal amount);
    }

    public sealed class CreditCard : IPayable
    {
        public void Pay(decimal amount) => Console.WriteLine($"  CreditCard.Pay: оплата картой на сумму {amount:F2}");
    }

    public sealed class Cash : IPayable
    {
        public void Pay(decimal amount) => Console.WriteLine($"  Cash.Pay: оплата наличными на сумму {amount:F2}");
    }

    public interface ILogger
    {
        void Log(string message);
    }

    public sealed class ConsoleLogger : ILogger
    {
        public void Log(string message) => Console.WriteLine($"  ConsoleLogger: {message}");
    }

    public sealed class FileLogger(string filePath) : ILogger
    {
        public void Log(string message) => File.AppendAllText(filePath, message + Environment.NewLine, Encoding.UTF8);
    }

    internal static class Program
    {
        private const string WorkMessage = "Работа выполнена.";
        private static int checks;
        private static int passed;

        private static int Main()
        {
            Console.OutputEncoding = Encoding.UTF8;
            CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
            Console.WriteLine("ЛР2. Часть 1. Интерфейсы");
            Console.WriteLine();

            Console.WriteLine("1. Базовые интерфейсы");
            var point = new Point(2, 3);
            IMovable movable = point;
            Console.WriteLine($"  Point до перемещения: {point}");
            movable.Move(4, -1);
            Console.WriteLine($"  Point после Move(4, -1): {point}");
            Check("Координаты после перемещения равны (6, 2)", point.X == 6 && point.Y == 2);

            var circle = new Circle(3);
            var rectangle = new Rectangle(3, 4);
            var drawables = new List<IDrawable> { circle, rectangle };
            var drawing = CaptureOutput(() => DrawAll(drawables));
            Check("DrawAll вызывает Draw для обеих фигур по порядку",
                drawing.SequenceEqual(["  Circle.Draw: радиус 3", "  Rectangle.Draw: стороны 3 × 4"]));
            Console.WriteLine();

            Console.WriteLine("2. Интерфейсы и наследование");
            PrintShapeInfo(circle);
            PrintShapeInfo(rectangle);
            I3DShape cube = new Cube(3);
            PrintShapeInfo(cube);
            Console.WriteLine($"  Cube: объём = {cube.GetVolume():0.###}");
            Check("Circle: площадь 9π, периметр 6π",
                NearlyEqual(circle.GetArea(), 9 * Math.PI) && NearlyEqual(circle.GetPerimeter(), 6 * Math.PI));
            Check("Rectangle: площадь 12, периметр 14", rectangle.GetArea() == 12 && rectangle.GetPerimeter() == 14);
            Check("Cube: площадь поверхности 54, сумма рёбер 36, объём 27",
                cube.GetArea() == 54 && cube.GetPerimeter() == 36 && cube.GetVolume() == 27);
            Console.WriteLine();

            Console.WriteLine("3. Сегрегация интерфейсов (ISP)");
            var printerOutput = CaptureOutput(() => ExerciseDevice(new ThickDevice.Printer()));
            var scannerOutput = CaptureOutput(() => ExerciseDevice(new ThickDevice.Scanner()));
            Check("Через IDevice вызваны Print, Scan и Fax. Printer выполняет только Print",
                printerOutput.SequenceEqual(["  IDevice Printer.Print"]));
            Check("Через IDevice вызваны Print, Scan и Fax. Scanner выполняет только Scan",
                scannerOutput.SequenceEqual(["  IDevice Scanner.Scan"]));

            var printer = new ISP.Printer();
            var scanner = new ISP.Scanner();
            var multifunction = new ISP.MultifunctionDevice();
            var ispOutput = CaptureOutput(() =>
            {
                Print(printer);
                Scan(scanner);
                Print(multifunction);
                Scan(multifunction);
                Fax(multifunction);
            });
            Check("Printer реализует только IPrinter", printer.GetType().GetInterfaces().SequenceEqual([typeof(ISP.IPrinter)]));
            Check("Scanner реализует только IScanner", scanner.GetType().GetInterfaces().SequenceEqual([typeof(ISP.IScanner)]));
            Check("МФУ выполняет Print, Scan и Fax через узкие интерфейсы", ispOutput.SequenceEqual([
                "  ISP Printer.Print", "  ISP Scanner.Scan", "  MultifunctionDevice.Print",
                "  MultifunctionDevice.Scan", "  MultifunctionDevice.Fax"
            ]));
            Console.WriteLine();

            Console.WriteLine("4. Интерфейсы и полиморфизм");
            var paymentOutput = CaptureOutput(() =>
            {
                ProcessPayment(new CreditCard(), 1250.50m);
                ProcessPayment(new Cash(), 300m);
            });
            Check("ProcessPayment передаёт сумму обоим способам оплаты", paymentOutput.SequenceEqual([
                "  CreditCard.Pay: оплата картой на сумму 1250.50", "  Cash.Pay: оплата наличными на сумму 300.00"
            ]));

            var consoleLog = CaptureOutput(() => DoWork(new ConsoleLogger()));
            Check("DoWork записывает сообщение через ConsoleLogger", consoleLog.SequenceEqual([$"  ConsoleLogger: {WorkMessage}"]));

            var logPath = Path.GetTempFileName();
            try
            {
                DoWork(new FileLogger(logPath));
                var fileLog = File.ReadAllText(logPath, Encoding.UTF8);
                Console.WriteLine($"  FileLogger (прочитано из файла): {fileLog.TrimEnd()}");
                Check("DoWork записывает сообщение через FileLogger", fileLog == WorkMessage + Environment.NewLine);
            }
            finally
            {
                File.Delete(logPath);
            }

            Console.WriteLine();
            Console.WriteLine($"Итого пройдено проверок: {passed}/{checks}");
            return passed == checks ? 0 : 1;
        }

        private static void DrawAll(List<IDrawable> items)
        {
            foreach (var item in items)
            {
                item.Draw();
            }
        }

        private static void PrintShapeInfo(IShape shape) =>
            Console.WriteLine($"  {shape.GetType().Name}: площадь = {shape.GetArea():0.###}, периметр = {shape.GetPerimeter():0.###}");

        private static void ExerciseDevice(ThickDevice.IDevice device)
        {
            device.Print();
            device.Scan();
            device.Fax();
        }

        private static void Print(ISP.IPrinter printer) => printer.Print();
        private static void Scan(ISP.IScanner scanner) => scanner.Scan();
        private static void Fax(ISP.IFax fax) => fax.Fax();
        private static void ProcessPayment(IPayable method, decimal amount) => method.Pay(amount);
        private static void DoWork(ILogger logger) => logger.Log(WorkMessage);
        private static bool NearlyEqual(double actual, double expected) => Math.Abs(actual - expected) < 1e-9;

        private static string[] CaptureOutput(Action action)
        {
            var original = Console.Out;
            using var buffer = new StringWriter();
            Console.SetOut(buffer);
            try
            {
                action();
            }
            finally
            {
                Console.SetOut(original);
            }

            var output = buffer.ToString();
            Console.Write(output);
            return output.Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries);
        }

        private static void Check(string description, bool condition)
        {
            checks++;
            if (condition)
            {
                passed++;
            }

            Console.WriteLine($"  [{(condition ? "PASS" : "FAIL")}] {description}");
        }
    }
}

namespace Lab02.Interfaces.ThickDevice
{
    public interface IDevice
    {
        void Print();
        void Scan();
        void Fax();
    }

    public sealed class Printer : IDevice
    {
        public void Print() => Console.WriteLine("  IDevice Printer.Print");
        public void Scan() { }
        public void Fax() { }
    }

    public sealed class Scanner : IDevice
    {
        public void Print() { }
        public void Scan() => Console.WriteLine("  IDevice Scanner.Scan");
        public void Fax() { }
    }
}

namespace Lab02.Interfaces.ISP
{
    public interface IPrinter
    {
        void Print();
    }

    public interface IScanner
    {
        void Scan();
    }

    public interface IFax
    {
        void Fax();
    }

    public sealed class Printer : IPrinter
    {
        public void Print() => Console.WriteLine("  ISP Printer.Print");
    }

    public sealed class Scanner : IScanner
    {
        public void Scan() => Console.WriteLine("  ISP Scanner.Scan");
    }

    public sealed class MultifunctionDevice : IPrinter, IScanner, IFax
    {
        public void Print() => Console.WriteLine("  MultifunctionDevice.Print");
        public void Scan() => Console.WriteLine("  MultifunctionDevice.Scan");
        public void Fax() => Console.WriteLine("  MultifunctionDevice.Fax");
    }
}
